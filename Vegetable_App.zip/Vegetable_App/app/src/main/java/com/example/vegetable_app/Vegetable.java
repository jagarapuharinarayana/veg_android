package com.example.vegetable_app;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Vegetable {

    @SerializedName("Image")
    @Expose
    private String image;
    @SerializedName("RetailPrice")
    @Expose
    private String retailPrice;
    @SerializedName("ShoppingMall")
    @Expose
    private String shoppingMall;
    @SerializedName("Units")
    @Expose
    private String units;
    @SerializedName("Vegetable")
    @Expose
    private String vegetable;
    @SerializedName("WholesalePrice")
    @Expose
    private String wholesalePrice;

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getRetailPrice() {
        return retailPrice;
    }

    public void setRetailPrice(String retailPrice) {
        this.retailPrice = retailPrice;
    }

    public String getShoppingMall() {
        return shoppingMall;
    }

    public void setShoppingMall(String shoppingMall) {
        this.shoppingMall = shoppingMall;
    }

    public String getUnits() {
        return units;
    }

    public void setUnits(String units) {
        this.units = units;
    }

    public String getVegetable() {
        return vegetable;
    }

    public void setVegetable(String vegetable) {
        this.vegetable = vegetable;
    }

    public String getWholesalePrice() {
        return wholesalePrice;
    }

    public void setWholesalePrice(String wholesalePrice) {
        this.wholesalePrice = wholesalePrice;
    }

}

